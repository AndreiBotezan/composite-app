import Header from "../components/Header"
import Carousel from "../components/Carousel"
import SectionBlock from "../components/SectionBlock"
import Footer from "../components/Footer"

export default function Homepage() {
  return (
    <div className="container">
      <Header />
      < Carousel />
      <SectionBlock 
        logo="../img/content1.jpg"
        title="Responsive Desing"
        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis non neque placerat, ullamcorper est eget, blandit sem. Nullam id augue non neque venenatis fringilla in vel ante. Maecenas facilisis turpis odio, vel egestas sem consequat ac. Donec tempus in nibh eu suscipit. Maecenas sed gravida tortor. Proin eu orci gravida, elementum felis vitae, vestibulum urna."
      />
      <SectionBlock 
        logo="../img/content2.jpg"
        title="Bootstrap"
        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis non neque placerat, ullamcorper est eget, blandit sem. Nullam id augue non neque venenatis fringilla in vel ante. Maecenas facilisis turpis odio, vel egestas sem consequat ac. Donec tempus in nibh eu suscipit. Maecenas sed gravida tortor. Proin eu orci gravida, elementum felis vitae, vestibulum urna."
      />
      <hr className="line" />
      <SectionBlock 
        logo="../img/content3.jpg"
        title="Google Web Fonts"
        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis non neque placerat, ullamcorper est eget, blandit sem. Nullam id augue non neque venenatis fringilla in vel ante. Maecenas facilisis turpis odio, vel egestas sem consequat ac. Donec tempus in nibh eu suscipit. Maecenas sed gravida tortor. Proin eu orci gravida, elementum felis vitae, vestibulum urna."
      />
      <SectionBlock 
        logo="../img/content4.jpg"
        title="User Friendly"
        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis non neque placerat, ullamcorper est eget, blandit sem. Nullam id augue non neque venenatis fringilla in vel ante. Maecenas facilisis turpis odio, vel egestas sem consequat ac. Donec tempus in nibh eu suscipit. Maecenas sed gravida tortor. Proin eu orci gravida, elementum felis vitae, vestibulum urna."
      />
      <Footer />
    </div>
  )
}