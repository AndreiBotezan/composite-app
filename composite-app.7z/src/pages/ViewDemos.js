import Header from "../components/Header"

export default function ViewDemos() {

  return (
    <div>
      <Header />
    </div>
  )
}