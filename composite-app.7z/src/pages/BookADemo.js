import Header from "../components/Header"

export default function BookADemo() {
  return (
    <div>
      <Header />
    </div>
  )
}