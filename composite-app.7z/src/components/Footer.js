export default function Header() {
  return (
    <div className="footer">
      <div>COMPOSITE {Date.prototype.getYear()} About us | Contact us</div>
    </div>
  )
}